/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agrold.ogust.membre;

/**
 *
 * @author Jc
 * @role : initialize an user connection
 */
public class login {
    
}
