/* 
*
*	Implementation of advanced search with ajax performance
*	@info need JQuery lib
*	Creator : J-C
*
*/
