WEBAPPURL="http://agrold.southgreen.fr";
//WEBAPPURL="http://localhost:8080/agrold";

// still constant in :
// /Users/zadmin/agrold/git/AgroLD/agrold/src/main/webapp/bc_sparqleditor.jsp
// /src/main/webapp/relfinder/config/Config.xml
// /src/main/webapp/sparqleditor.jsp
SPARQLENDPOINTURL="http://sparql.southgreen.fr"; 
// 
// stil in HTML form in :
//  WEB-INF/Account/General/AJAX/Admin/_USER_FULL_DATA_LOADER.jsp
// WEB-INF/Account/General/AJAX/History/QuickSearchList.jsp 
// /src/main/webapp/quicksearch.jsp
FACETEDURL="http://volvestre.cirad.fr:8890/fct/"; 

AGROLDAPIJSONURL=WEBAPPURL + "/config/agrold-api.json";
//AGROLDAPIJSONURL="http://localhost/agrold/config/agrold.json";


// Advanced search default service web query format
DEFAULTAPIFORMAT = ".jsonld";